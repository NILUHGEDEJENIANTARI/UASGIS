package com.example.siguas;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String[]nama,alamat,foto;
    private Integer[]id;
    Boolean MarkerD[];
    int jumdata;
    private Double[]latitude,longitude;
    LatLng latLng[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        tampilpeta();

        // Add a marker in Sydney and move the camera
          LatLng roasted = new LatLng(-8.659828837284293, 115.14079561087851);
          mMap.addMarker(new MarkerOptions().position(roasted).title("Roasted di Canggu"));
          mMap.moveCamera(CameraUpdateFactory.newLatLng(roasted));

        LatLng manggis = new LatLng(-8.659043953700087, 115.13818850367483);
        mMap.addMarker(new MarkerOptions().position(manggis).title("Manggis di Canggu"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(manggis));

        LatLng alka = new LatLng(-8.659151519879561, 115.13402536431433);
        mMap.addMarker(new MarkerOptions().position(alka).title("Alkaline Restaurant"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(alka));

        LatLng peloton = new LatLng(-8.660682719921892, 115.14661905420202);
        mMap.addMarker(new MarkerOptions().position(peloton).title("Peloton Supershop"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(peloton));

        LatLng taco = new LatLng(-8.651326759818138, 115.1298582687935);
        mMap.addMarker(new MarkerOptions().position(taco).title("Taco Casa Canggu"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(taco));
    }

    private void tampilpeta() {
        String Url="http://192.168.56.1/uasgis/koneksi.php";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, Url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                jumdata = response.length();
                Log.d("DEBUG", "Parse JSON");
                latLng = new LatLng[jumdata];
                MarkerD = new Boolean[jumdata];
                nama = new String[jumdata];
                alamat = new String[jumdata];
                foto = new String[jumdata];
                id = new Integer[jumdata];
                latitude= new Double[jumdata];
                longitude= new Double[jumdata];
                for (int i = 0; i < jumdata; i++) {
                    try {
                        JSONObject data = response.getJSONObject(i);
                        id[i] = data.getInt("id");
                        latLng[i] = new LatLng(data.getDouble("latitude"), data.getDouble("longitude"));
                        nama[i] = data.getString("nama");
                        alamat[i] = data.getString("alamat");
                        foto[i] = data.getString("foto");
                        longitude[i] = data.getDouble("longitude");
                        latitude[i] = data.getDouble("latitude");
                        MarkerD[i] = false;
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng[i])
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.icon))
                                .title(nama[i]));

                    } catch (JSONException e) {

                    }
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng[i], 15.5f));
                }
                mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                    @Override
                    public boolean onMarkerClick(@NonNull Marker marker) {
                        for (int i=0;i<jumdata;i++){
                            if (marker.getTitle().equals(nama[i])) {
                                if (MarkerD[i]) {
                                    DetailActivity.nama = nama[i];
                                    DetailActivity.alamat = alamat[i];
                                    Intent pindahdetail = new Intent(MapsActivity.this, DetailActivity.class);
                                    startActivity(pindahdetail);
                                    MarkerD[i] = false;

                                } else {
                                    MarkerD[i] = true;
                                    marker.showInfoWindow();
                                    Toast pesan = Toast.makeText(MapsActivity.this, "silahkan klik untuk detail", Toast.LENGTH_LONG);
                                    TextView tv = pesan.getView().findViewById(R.id.message);
                                    if (tv != null)
                                        tv.setGravity(Gravity.CENTER);
                                    pesan.show();
                                }


                            } else{
                                    MarkerD[i] = false;
                            }
                        }
                        return false;
                    }

                });
            }

                }, new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
                        builder.setTitle("error");
                        builder.setMessage("failed");
                        builder.setPositiveButton("reload", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                tampilpeta();
                            }
                        });
                        AlertDialog alert= builder.create();
                        alert.show();
                    }
                });
                Volley.newRequestQueue(this).add(request);
            }
    }