package com.example.siguas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
TextView tvnama,tvalamat;
public static String nama,alamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvnama=findViewById(R.id.txtnama);
        tvalamat=findViewById(R.id.txtalamat);

        tvnama.setText(nama);
        tvalamat.setText(alamat);

    }
}
