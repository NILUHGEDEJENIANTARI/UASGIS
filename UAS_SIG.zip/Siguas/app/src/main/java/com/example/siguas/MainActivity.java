package com.example.siguas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView ivmap1,ivmap2,ivmap3,ivmap4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivmap1=findViewById(R.id.btnpeta1);
        ivmap2=findViewById(R.id.btnpeta2);
        ivmap3=findViewById(R.id.btnpeta3);
        ivmap4=findViewById(R.id.btnpeta4);

        ivmap1.setOnClickListener(this);
        ivmap2.setOnClickListener(this);
        ivmap3.setOnClickListener(this);
        ivmap4.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent pindahpeta= new Intent(MainActivity.this,MapsActivity.class);
        startActivity(pindahpeta);

    }
}
