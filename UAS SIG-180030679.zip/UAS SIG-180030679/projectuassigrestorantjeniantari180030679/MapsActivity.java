 package com.example.uassigrestourant;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.uassigrestourant.databinding.ActivityMapsBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String[]nama,alamat,photo;
    private Integer[]id;
    Boolean MarkerD[];

    int jumlahdata;
    private Double[]latitude,longitude;
    LatLng[] latlng;

    //private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       //binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_maps);

        //Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        tampilpeta();

//         Add a marker in Sydney and move the camera
//            LatLng sydney = new LatLng(-34, 151);
//           mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    private void tampilpeta() {
       String Url="http://172.20.10.3/UASSIG/koneksi.php";
       JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,Url, new Response.Listener<JSONArray>() {
           @Override
           public void onResponse(JSONArray response) {
               jumlahdata=response.length();
               Log.d("DEBUG", "PARSE JSON");
                latlng=new LatLng[jumlahdata];
               MarkerD=new Boolean[jumlahdata];
               nama=new String[jumlahdata];
               alamat=new String[jumlahdata];
               photo=new String[jumlahdata];
               id=new Integer[jumlahdata];
                for (int i=0;i<jumlahdata;i++) {
                    try {
                        JSONObject data= response.getJSONObject(i);
                        id[i]=data.getInt("id");
                        latlng[i]=new LatLng(data.getDouble("latitude"),data.getDouble("longitude"));
                        nama[i]=data.getString("nama");
                       alamat[i]=data.getString("alamat");
                        photo[i]=data.getString("photo");
                        latitude[i]= data.getDouble("latitude");
                        longitude[i]= data.getDouble("longitude");
                        MarkerD[i]=false;
                        mMap.addMarker(new MarkerOptions()
                                .position(latlng[i])
                                //.icon(BitmapDescriptorFactory.fromResource(R.drawable.icon))
                                .title(nama[i]));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng[i], 15.5f));
                }
                mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                    @Override
                    public boolean onMarkerClick(@NonNull Marker marker) {
                        for(int i=0;i<jumlahdata;i++){
                            if (marker.getTitle().equals(nama[i])){
                                if (MarkerD[i]){
                                    DetailActivity.nama=nama[i];
                                    DetailActivity.alamat=alamat[i];
                                    DetailActivity.photo=photo[i];
                                    Intent pindahdetail = new Intent(MapsActivity.this,DetailActivity.class);
                                    startActivity(pindahdetail);
                                    MarkerD[i]=false;

                                }else{
                                    MarkerD[i]=true;
                                    marker.showInfoWindow();
                                    Toast pesan = Toast.makeText(MapsActivity.this," silahkan klik untuk detail", Toast.LENGTH_LONG);
                                    TextView tv = pesan.getView().findViewById(R.id.message);
                                    if (tv !=null)
                                        tv.setGravity(Gravity.CENTER);
                                    pesan.show();
                                }

                            }else{
                                MarkerD[i]=false;
                            }
                        }
                        return false;
                    }
                });
           }

                }, new  Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
                        builder.setTitle("error");
                        builder.setMessage("failed");
                        builder.setPositiveButton("reload", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                tampilpeta();
                            }
                        });
                        AlertDialog alert= builder.create();
                        alert.show();
                    }
       });
               Volley.newRequestQueue(this).add(request);
    }
}