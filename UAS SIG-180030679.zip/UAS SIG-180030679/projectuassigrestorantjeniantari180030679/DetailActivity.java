package com.example.uassigrestourant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.app.AppComponentFactory;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.uassigrestourant.databinding.ActivityDetail2Binding;

public class DetailActivity extends AppCompatActivity {
TextView tvnama,tvalamat,tvphoto;
public static String nama,alamat,photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvnama=findViewById(R.id.txtnama);
        tvalamat=findViewById(R.id.txtalamat);
        tvphoto=findViewById(R.id.txtphoto);

        tvnama.setText(nama);
        tvalamat.setText(alamat);
        tvphoto.setText(photo);

    }
}