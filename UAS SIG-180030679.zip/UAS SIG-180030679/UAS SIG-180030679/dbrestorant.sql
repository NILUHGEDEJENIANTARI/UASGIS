-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Jun 2021 pada 08.46
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbrestorant`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_restorant`
--

CREATE TABLE `t_restorant` (
  `id` int(10) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `t_restorant`
--

INSERT INTO `t_restorant` (`id`, `nama`, `alamat`, `photo`, `latitude`, `longitude`) VALUES
(1, 'Roasted Di Canggu', 'Jl. Pantai Berawa No.46X, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Queen_Lobster.jpg/640px-Queen_Lobster.jpg', -8.659828837284293, 115.14079561087851),
(2, 'Manggis in Canggu', 'Jl. Pemelisan Agung No.7, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:The_Horse_and_Groom_Pub._Windsor,_UK.jpg', -8.659043953700087, 115.13818850367483),
(3, 'Alkaline Restaurant', 'Serenity Eco Guesthouse and Yoga, Jl. Nelayan No.Banjar, Canggu, North Kuta, Badung Regency, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Norderney,_Weststrand,_Hotel_--_2018_--_1050.jpg', -8.659151519879561, 115.13402536431433),
(4, 'Peloton Supershop', 'Jl. Pantai Berawa No.46, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Illuminated_facade_of_a_3-storey_restaurant_with_Japanese_signs_and_red_paper_lanterns,_Chiyoda,_Tokyo.jpg', -8.660682719921892, 115.14661905420202),
(5, 'Lola’s Cantina Mexicana - Canggu', 'Unnamed Road, Canggu, North Kuta, Badung Regency, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Ngahere_Gallery,_Murchison,_New_Zealand.jpg', -8.653265119127198, 115.13782008300561),
(6, 'Taco Casa Canggu', 'Jl. Batu Mejan Canggu, Canggu, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Amboy_(California,_USA)_--_2012_--_4.jpg', -8.651326759818138, 115.1298582687935),
(7, 'Ithaka Warung', 'Jl. Pantai Batu Bolong No.168, Canggu, Kec. Kuta Utara, Kabupaten Badung, Bali 80351', 'https://commons.wikimedia.org/wiki/File:Sorry_Charlie%27s_Oyster_Bar,_Barnard_St,_Savannah_GA_20160705_1.jpg', -8.657746233332094, 115.1308742445572),
(8, 'Milk & Madu', 'Jl. Pantai Berawa No.52, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Desserts_and_Wine.jpg', -8.660219392296469, 115.1460197963351),
(9, 'Indigo', 'Jl. Pantai Berawa No.7A, Canggu, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Wirtshausschild_Restaurant_Krone_in_Gonten_AI.jpg', -8.652672699920041, 115.14825591624948),
(10, 'Suksema Sushi Bar', 'Jalan Taman Wisata, Tibubeneng, Canggu, Kuta Utara, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:Salish_Studio_in_Ganges,_Saltspring_Island,_British_Columbia,_Canada.jpg', -8.663526462567692, 115.14659577078884),
(11, 'Café del Mar Bali', 'Jl. Subak Sari, Canggu, Tibubeneng, Kec. Kuta Utara, Kabupaten Badung, Bali 80361', 'https://commons.wikimedia.org/wiki/File:M%C3%BCnster,_Kiepenkerl_--_2018_--_3646.jpg', -8.670039675259451, 115.14459460800116);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `t_restorant`
--
ALTER TABLE `t_restorant`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
